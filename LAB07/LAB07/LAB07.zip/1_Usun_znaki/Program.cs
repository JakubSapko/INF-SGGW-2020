﻿using System;
using Moja;

namespace RunCode
{
    class Program
    {
        static void Main(string[] args)
        {
            string tekst = "t\\ta;T-a";
            Console.WriteLine(Moja.Class1.UsunZnaki(tekst));
            Console.ReadKey();
        }
    }
}